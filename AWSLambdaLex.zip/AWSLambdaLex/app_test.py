import json
from tabulate import tabulate

payload = '{"graph": "Chicago->Urbana,Urbana->Springfield,Chicago->Lafayette"}'
city_map = json.loads(payload)
print(city_map['graph'])
table = []
table_headers = ['Source', 'Taget', 'Destination']
sample_table = tabulate(table, headers=table_headers)
print(sample_table)

