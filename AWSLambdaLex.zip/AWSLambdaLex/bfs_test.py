graph = {
  '5' : ['3','7'],
  '3' : ['2', '4'],
  '7' : ['8'],
  '2' : [],
  '4' : ['8'],
  '8' : []
}

visited = [] # List for visited nodes.
queue = []     #Initialize a queue
distances = []
levels = []
def bfs(visited, graph, node): #function for BFS
    visited.append(node)
    queue.append(node)
    levels.append(node)
    i = 1

    while queue:          # Creating loop to visit each node
        
        m = queue.pop(0) 
        #print(m) 
        
        for neighbour in graph[m]:
            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)
                levels.append(neighbour)
                #print(queue)
                distances.append((neighbour, i))
                print(distances)
        if m not in levels:
            i = i+1
            # pop levels however many times the first value has
            
            levels = []
            
        
        
        # if m != m_previous:
        #     i = i + 1
        # m_previous = previous.pop(0)
        # print('Previous Node: {}').format(m_previous)
        # print ('Node: %3d, Distance: %2d' % (m, i))
        

# Driver Code
print("Following is the Breadth-First Search")
bfs(visited, graph, '5')    # function calling
print(previous)