graph = {
  'Chicago': ['Urbana', 'Lafayette'], 
  'Urbana': ['Springfield'], 
  'Springfield': [], 
  'Lafayette': []
}

def shortest_path(graph, node1, node2):
    path_list = [[node1]]
    path_index = 0
    # To keep track of previously visited nodes
    previous_nodes = {node1}
    if node1 == node2:
        return path_list[0]
        #return len(path_list[0]) - 1
        
    while path_index < len(path_list):
        current_path = path_list[path_index]
        last_node = current_path[-1]
        next_nodes = graph[last_node]
        # Search goal node
        if node2 in next_nodes:
            current_path.append(node2)
            return current_path
            #return len(current_path) - 1
        # Add new paths
        for next_node in next_nodes:
            if not next_node in previous_nodes:
                new_path = current_path[:]
                new_path.append(next_node)
                path_list.append(new_path)
                # To avoid backtracking
                previous_nodes.add(next_node)
        # Continue to next path in list
        path_index += 1
    # No path is found
    return []

#print(shortest_path(graph, 'Chicago', 'Springfield'))
#print(shortest_path(graph, 'Chicago', 'Urbana'))
#print(shortest_path(graph, 'Urbana', 'Springfield'))
#print(shortest_path(graph, 'Chicago', 'Lafayette'))
#print(shortest_path(graph, 'Lafayette', 'Springfield'))
#print(graph.keys())
def all_city_dists():
    for city in graph.keys():
        for other_city in graph.keys():
            path = shortest_path(graph, other_city, city)
            print(shortest_path(graph, other_city, city))
            if len(path) == 1:
                dist = 

print(all_city_dists())
ex = []
print(len(ex))
