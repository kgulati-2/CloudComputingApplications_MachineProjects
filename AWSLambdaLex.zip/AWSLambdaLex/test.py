import requests
import json
import uuid

url = "https://seorwrpmwh.execute-api.us-east-1.amazonaws.com/prod/mp3-autograder-2022-spring"

payload = {
	"graphApi": 'https://8puxbwagei.execute-api.us-east-1.amazonaws.com/mp3_1/distance',
	"botName": 'Get_City_Distances', 
	"botAlias": 'city_dist_bot',
	"identityPoolId": 'us-east-1:f6a36ccc-5848-4ac4-bf27-99add8298e65',
	"accountId": '030067900660',
	"submitterEmail": 'kgulati2@illinois.edu',
	"secret": '41YB03fwynNHYtZn',
	"region": 'us-east-1'
    }

r = requests.post(url, data=json.dumps(payload))

print(r.status_code, r.reason)
print(r.text)